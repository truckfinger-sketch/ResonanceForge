"""
ResonanceForge - Open Multiphysics Simulation Platform

A free, open-source alternative to COMSOL with φⁿ golden ratio optimization
and empirical resonance frequency integration.

Copyright (C) 2024 ResonanceForge Contributors
Licensed under GPL-3.0-or-later
"""

from .__version__ import __version__

__author__ = "ResonanceForge Contributors"
__email__ = "contact@resonanceforge.org"
__license__ = "GPL-3.0-or-later"
__url__ = "https://resonanceforge.org"

# Golden ratio constant
PHI = (1 + 5**0.5) / 2

__all__ = ['__version__', 'PHI']
