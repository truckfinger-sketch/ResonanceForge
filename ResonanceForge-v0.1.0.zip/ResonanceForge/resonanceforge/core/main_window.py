"""
ResonanceForge Main Application Window

COMSOL-like interface with Model Builder tree, 3D viewport, and properties panel.
"""

import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTreeWidget, QTreeWidgetItem, QMenuBar, QMenu,
    QToolBar, QStatusBar, QMessageBox, QFileDialog
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QAction, QIcon

try:
    import pyvista as pv
    from pyvistaqt import QtInteractor
    PYVISTA_AVAILABLE = True
except ImportError:
    PYVISTA_AVAILABLE = False
    print("Warning: PyVista not available. 3D visualization disabled.")


class ResonanceForgeApp(QMainWindow):
    """Main application window for ResonanceForge"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ResonanceForge - Open Multiphysics Platform")
        self.setGeometry(100, 100, 1400, 900)
        
        self.current_model = None
        self.init_ui()
        
    def init_ui(self):
        """Initialize user interface"""
        # Create menu bar
        self.create_menus()
        
        # Create toolbar
        self.create_toolbar()
        
        # Create central widget with splitters
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Create three-panel layout (Model Builder | 3D View | Properties)
        main_splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # Left panel: Model Builder tree
        self.model_tree = self.create_model_tree()
        main_splitter.addWidget(self.model_tree)
        
        # Center panel: 3D viewport
        if PYVISTA_AVAILABLE:
            self.viewport_3d = QtInteractor()
            main_splitter.addWidget(self.viewport_3d)
        else:
            from PyQt6.QtWidgets import QLabel
            placeholder = QLabel("3D Viewport\n(PyVista not installed)")
            placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
            placeholder.setStyleSheet("background-color: #2b2b2b; color: white; font-size: 16px;")
            main_splitter.addWidget(placeholder)
        
        # Right panel: Properties panel (placeholder)
        from PyQt6.QtWidgets import QTextEdit
        self.properties_panel = QTextEdit()
        self.properties_panel.setPlaceholderText("Properties Panel\n\nSelect a node in Model Builder to view properties")
        self.properties_panel.setMaximumWidth(300)
        main_splitter.addWidget(self.properties_panel)
        
        # Set initial sizes (20% | 60% | 20%)
        main_splitter.setSizes([280, 840, 280])
        
        main_layout.addWidget(main_splitter)
        
        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready | φ = 1.618034...")
        
    def create_menus(self):
        """Create application menus"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("&File")
        
        new_action = QAction("&New Model", self)
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.new_model)
        file_menu.addAction(new_action)
        
        open_action = QAction("&Open...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_model)
        file_menu.addAction(open_action)
        
        save_action = QAction("&Save", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_model)
        file_menu.addAction(save_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Physics menu
        physics_menu = menubar.addMenu("&Physics")
        
        modules = [
            "Electric Motor (BLDC)",
            "Turbopump (Rocket)",
            "Battery Cell",
            "Battery Pack Thermal",
            "Solar Cell",
            "Combustion Chamber",
            "Heat Shield (Hypersonic)",
            "Water Treatment (25.92 kHz)",
            "Biomedical Healing (528 Hz)",
            "Quantum E₈ Lattice",
            "Railgun"
        ]
        
        for module in modules:
            action = QAction(module, self)
            action.triggered.connect(lambda checked, m=module: self.add_physics_module(m))
            physics_menu.addAction(action)
        
        # Tools menu
        tools_menu = menubar.addMenu("&Tools")
        
        phi_opt_action = QAction("φⁿ Optimizer", self)
        phi_opt_action.triggered.connect(self.run_phi_optimizer)
        tools_menu.addAction(phi_opt_action)
        
        mesh_action = QAction("Mesh Generator", self)
        mesh_action.triggered.connect(self.open_mesh_generator)
        tools_menu.addAction(mesh_action)
        
        # Help menu
        help_menu = menubar.addMenu("&Help")
        
        docs_action = QAction("Documentation", self)
        docs_action.triggered.connect(self.open_documentation)
        help_menu.addAction(docs_action)
        
        about_action = QAction("About ResonanceForge", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
    def create_toolbar(self):
        """Create application toolbar"""
        toolbar = QToolBar("Main Toolbar")
        self.addToolBar(toolbar)
        
        # Add common actions
        toolbar.addAction("New")
        toolbar.addAction("Open")
        toolbar.addAction("Save")
        toolbar.addSeparator()
        toolbar.addAction("Mesh")
        toolbar.addAction("Solve")
        toolbar.addAction("Plot")
        
    def create_model_tree(self):
        """Create COMSOL-like model builder tree"""
        tree = QTreeWidget()
        tree.setHeaderLabel("Model Builder")
        tree.setColumnCount(1)
        
        # Add example structure
        root = QTreeWidgetItem(tree, ["ResonanceForge Model"])
        
        global_node = QTreeWidgetItem(root, ["Global Definitions"])
        QTreeWidgetItem(global_node, ["Parameters"])
        QTreeWidgetItem(global_node, ["Variables"])
        
        geometry_node = QTreeWidgetItem(root, ["Geometry"])
        QTreeWidgetItem(geometry_node, ["Work Plane 1"])
        
        materials_node = QTreeWidgetItem(root, ["Materials"])
        
        physics_node = QTreeWidgetItem(root, ["Physics"])
        
        mesh_node = QTreeWidgetItem(root, ["Mesh"])
        
        study_node = QTreeWidgetItem(root, ["Study"])
        QTreeWidgetItem(study_node, ["Solver Configurations"])
        
        results_node = QTreeWidgetItem(root, ["Results"])
        
        tree.expandAll()
        
        # Connect selection change
        tree.itemClicked.connect(self.on_tree_item_clicked)
        
        return tree
        
    def on_tree_item_clicked(self, item, column):
        """Handle tree item selection"""
        self.status_bar.showMessage(f"Selected: {item.text(0)}")
        self.properties_panel.setText(f"Properties for: {item.text(0)}\n\n[Properties would appear here]")
        
    def new_model(self):
        """Create new model"""
        QMessageBox.information(self, "New Model", "Creating new model...")
        
    def open_model(self):
        """Open existing model"""
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open Model", "", "ResonanceForge Files (*.rforge);;All Files (*)"
        )
        if filename:
            self.status_bar.showMessage(f"Opening: {filename}")
            
    def save_model(self):
        """Save current model"""
        filename, _ = QFileDialog.getSaveFileName(
            self, "Save Model", "", "ResonanceForge Files (*.rforge)"
        )
        if filename:
            self.status_bar.showMessage(f"Saved: {filename}")
            
    def add_physics_module(self, module_name):
        """Add physics module to model"""
        QMessageBox.information(self, "Add Physics", f"Adding module: {module_name}")
        
    def run_phi_optimizer(self):
        """Run φⁿ golden ratio optimizer"""
        QMessageBox.information(
            self, 
            "φⁿ Optimizer", 
            "Golden Ratio Optimizer\n\nφ = 1.618034...\n\nScanning model for φⁿ optimization opportunities..."
        )
        
    def open_mesh_generator(self):
        """Open mesh generator"""
        QMessageBox.information(self, "Mesh Generator", "Opening mesh generator...")
        
    def open_documentation(self):
        """Open documentation"""
        QMessageBox.information(
            self,
            "Documentation",
            "Documentation:\nhttps://resonanceforge.org/docs\n\nLocal docs in docs/ folder"
        )
        
    def show_about(self):
        """Show about dialog"""
        about_text = """
        <h2>ResonanceForge</h2>
        <p><b>Version 0.1.0</b></p>
        
        <p>Open Multiphysics Simulation Platform with φⁿ Optimization</p>
        
        <p><b>Democratizing Computational Physics</b></p>
        
        <p>Free alternative to COMSOL with unique features:
        <ul>
        <li>φⁿ golden ratio optimization</li>
        <li>Empirical resonance frequency library</li>
        <li>Multi-solver backend (Elmer, OpenFOAM, CalculiX)</li>
        <li>Collaborative post-it notes</li>
        </ul>
        </p>
        
        <p>Licensed under GPL-3.0-or-later</p>
        
        <p>Copyright © 2024 ResonanceForge Contributors</p>
        
        <p><a href="https://resonanceforge.org">resonanceforge.org</a></p>
        """
        
        QMessageBox.about(self, "About ResonanceForge", about_text)


def main():
    """Application entry point"""
    app = QApplication(sys.argv)
    app.setApplicationName("ResonanceForge")
    app.setOrganizationName("ResonanceForge")
    
    # Set dark theme (optional)
    app.setStyle("Fusion")
    
    window = ResonanceForgeApp()
    window.show()
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
