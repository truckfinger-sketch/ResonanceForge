"""
ResonanceForge Core Module

Contains main application window, model tree, 3D viewport, and GUI components.
"""

from .main_window import ResonanceForgeApp, main

__all__ = ['ResonanceForgeApp', 'main']
