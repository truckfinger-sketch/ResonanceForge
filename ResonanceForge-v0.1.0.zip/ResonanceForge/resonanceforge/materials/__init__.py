"""ResonanceForge module"""
