# ResonanceForge Examples

This directory contains example simulations demonstrating ResonanceForge capabilities.

## Quick Start Examples

### demo_phi_resonance.py
Simple φⁿ golden ratio resonance detection demo.
**No external solvers required** - runs pure Python.

```bash
python examples/quickstart/demo_phi_resonance.py
```

## Physics Module Examples

More advanced examples (require Elmer/OpenFOAM/CalculiX):

- `electric_motor/` - BLDC motor electromagnetic analysis
- `turbopump/` - Rocket turbopump NPSH optimization
- `battery_pack/` - Tesla 4680 thermal management
- `combustion/` - Methane/LOX rocket chamber
- `heat_shield/` - Hypersonic re-entry ablation

## Running Examples

1. Ensure solvers are installed (see docs/installation.md)
2. Activate virtual environment: `source venv/bin/activate`
3. Run example: `python examples/<module>/<script>.py`

## Contributing Examples

Have a cool simulation? Submit it as a pull request!

Include:
- Clear comments
- Expected runtime
- Validation data (if available)
