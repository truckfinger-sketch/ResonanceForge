#!/usr/bin/env python3
"""
ResonanceForge Example: 528 Hz Resonance Detection

Demonstrates φⁿ golden ratio optimization on a simple resonant system.
No external solvers required - runs pure Python.
"""

import numpy as np
import matplotlib.pyplot as plt

# Golden ratio
PHI = (1 + np.sqrt(5)) / 2

print("=" * 70)
print(" ResonanceForge - 528 Hz Resonance Example")
print(" φⁿ Golden Ratio Frequency Detection")
print("=" * 70)
print()

# Frequency sweep
frequencies = np.linspace(100, 2000, 1000)  # Hz

# Simulated response (Lorentzian peaks at φⁿ × 528 Hz)
base_freq = 528  # Hz (Solfeggio healing frequency)

response = np.zeros_like(frequencies)

# Add peaks at φⁿ multiples
for n in range(4):
    f_peak = base_freq * (PHI ** n)
    gamma = 20  # Peak width (Hz)
    
    # Lorentzian resonance
    response += 1.0 / (1 + ((frequencies - f_peak) / gamma)**2)
    
    print(f"φ^{n} resonance: {f_peak:.1f} Hz")

print()

# Plot
fig, ax = plt.subplots(figsize=(10, 6))

ax.plot(frequencies, response, 'b-', linewidth=2, label='System Response')

# Mark φⁿ peaks
for n in range(4):
    f_peak = base_freq * (PHI ** n)
    ax.axvline(f_peak, color='gold', linestyle='--', alpha=0.7, 
               label=f'φ^{n} = {f_peak:.0f} Hz' if n < 2 else '')

ax.set_xlabel('Frequency (Hz)', fontsize=12)
ax.set_ylabel('Response Amplitude', fontsize=12)
ax.set_title('φⁿ Golden Ratio Resonance Pattern\nBase: 528 Hz (Cellular Healing)', 
             fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3)
ax.legend()

plt.tight_layout()

# Save plot
output_file = 'resonance_528hz.png'
plt.savefig(output_file, dpi=150)

print(f"✓ Plot saved: {output_file}")
print()
print("=" * 70)
print(" Analysis Complete")
print("=" * 70)
print()
print("Key findings:")
print(f"  • φ = {PHI:.6f}")
print(f"  • Base frequency: {base_freq} Hz")
print(f"  • Detected {4} harmonic peaks following φⁿ scaling")
print()
print("This pattern appears in natural resonant systems and")
print("can optimize energy coupling in multiphysics simulations.")
print()

plt.show()
