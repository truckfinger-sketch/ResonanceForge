# Contributing to ResonanceForge

Thank you for your interest! We welcome contributions of all kinds.

## Ways to Contribute

- **Report bugs** - Create GitHub Issues
- **Add physics modules** - See docs/developer/
- **Improve documentation** - Fix typos, add tutorials
- **Share validation data** - Help verify accuracy

## Development Setup

```bash
git clone https://github.com/yourorg/ResonanceForge.git
cd ResonanceForge
python -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
```

## Code Style

- Follow PEP 8
- Use `black` for formatting (100 char line length)
- Add docstrings (NumPy style)
- Include tests for new features

## Pull Request Process

1. Fork the repository
2. Create feature branch: `git checkout -b feature/your-feature`
3. Make changes and add tests
4. Run tests: `pytest tests/`
5. Format code: `black resonanceforge/`
6. Submit pull request with clear description

## License

By contributing, you agree your contributions will be licensed under GPL-3.0.

## Questions?

Open a GitHub Discussion or email: contact@resonanceforge.org
