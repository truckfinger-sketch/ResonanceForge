"""
Basic tests for ResonanceForge core functionality
"""

import pytest
import numpy as np
from resonanceforge import PHI


def test_golden_ratio_value():
    """Test that φ is calculated correctly"""
    expected_phi = (1 + np.sqrt(5)) / 2
    assert abs(PHI - expected_phi) < 1e-10


def test_phi_powers():
    """Test φⁿ sequence"""
    # Fibonacci property: φⁿ = φⁿ⁻¹ + φⁿ⁻²
    phi_2 = PHI ** 2
    phi_1 = PHI ** 1
    phi_0 = PHI ** 0
    
    assert abs(phi_2 - (phi_1 + phi_0)) < 1e-10


def test_import():
    """Test that main modules can be imported"""
    try:
        from resonanceforge.core import main_window
        from resonanceforge import __version__
        assert True
    except ImportError as e:
        pytest.fail(f"Import failed: {e}")


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
