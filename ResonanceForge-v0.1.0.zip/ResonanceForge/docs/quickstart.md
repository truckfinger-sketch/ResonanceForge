# Quick Start Guide

Welcome to ResonanceForge! This guide will get you running your first simulation in 5 minutes.

## Installation

If you haven't installed yet:

```bash
python install.py
```

This creates a virtual environment and installs all dependencies.

## Launching ResonanceForge

### Windows
```
run_resonanceforge.bat
```

### Linux/macOS
```
./run_resonanceforge.sh
```

Or manually:
```bash
source venv/bin/activate
python -m resonanceforge
```

## Your First Simulation

### Option 1: GUI

1. Launch ResonanceForge
2. Click **Physics** → **Electric Motor (BLDC)**
3. The Model Builder tree will populate with physics nodes
4. Click **Mesh** → **Build All**
5. Click **Study** → **Compute**
6. View results in **Results** node

### Option 2: Python Script

Create `my_first_sim.py`:

```python
from resonanceforge.physics.electric_motor import BLDCMotorModel

# Create model
motor = BLDCMotorModel()
motor.config['name'] = 'My First Motor'

# Apply φⁿ optimization
motor.phi_optimize_geometry()

# Generate geometry
motor.create_geometry()

# Mesh
motor.create_mesh()

# Solve (requires Elmer)
results = motor.run_simulation()

# Plot
motor.plot_results(results)

print(f"Torque: {results['torque_avg']:.2f} N·m")
print(f"Efficiency: {results['efficiency']:.1%}")
```

Run it:
```bash
python my_first_sim.py
```

## Next Steps

- Explore other physics modules in `examples/`
- Read the [User Guide](user_guide/)
- Try [validation examples](../examples/validation/)
- Learn about [φⁿ optimization](theory/phi_optimization.md)

## Getting Help

- **Documentation**: https://resonanceforge.org/docs
- **GitHub Issues**: Bug reports and feature requests
- **Email**: contact@resonanceforge.org

---

**Tip**: Start with small models and verify against known solutions before tackling complex simulations.
