# ResonanceForge Documentation

Welcome to the ResonanceForge documentation!

## Getting Started

- [Quick Start](quickstart.md) - 5-minute introduction
- [Installation](installation.md) - Detailed setup guide

## User Guide

- [GUI Overview](user_guide/gui_overview.md)
- [Creating Models](user_guide/creating_models.md)
- [Running Simulations](user_guide/running_simulations.md)

## Physics Modules

Each physics module has detailed documentation:

- [Electric Motor](physics_modules/electric_motor.md)
- [Turbopump](physics_modules/turbopump.md)
- [Battery Pack](physics_modules/battery_pack.md)
- [Combustion](physics_modules/combustion.md)
- [And more...](physics_modules/)

## Theory

- [φⁿ Golden Ratio Optimization](theory/phi_optimization.md)
- [Resonance Physics](theory/resonance_physics.md)
- [Biblical Frequencies](theory/biblical_frequencies.md)

## Developer Guide

- [Architecture](developer/architecture.md)
- [Adding Modules](developer/adding_modules.md)
- [API Reference](developer/api_reference.md)

## Validation

- [Methodology](validation/methodology.md)
- [Benchmarks](validation/benchmarks.md)
- [Results](validation/results/)

---

**Need help?** Contact: contact@resonanceforge.org
