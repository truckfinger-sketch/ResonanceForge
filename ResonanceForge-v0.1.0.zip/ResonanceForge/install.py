#!/usr/bin/env python3
"""
ResonanceForge Installation Script
"""

import sys
import subprocess
import platform
from pathlib import Path

print("=" * 70)
print(" ResonanceForge Installation")
print(" Open Multiphysics Platform with φⁿ Optimization")
print("=" * 70)
print()

# Check Python version
if sys.version_info < (3, 8):
    print("ERROR: Python 3.8+ required")
    sys.exit(1)

print(f"✓ Python {sys.version_info.major}.{sys.version_info.minor}")

# Create virtual environment
print("\n[1/4] Creating virtual environment...")
venv_path = Path("venv")

if not venv_path.exists():
    subprocess.run([sys.executable, "-m", "venv", "venv"], check=True)
    print("✓ Virtual environment created")
else:
    print("⚠ Virtual environment already exists")

# Get venv python
if platform.system() == "Windows":
    venv_python = venv_path / "Scripts" / "python.exe"
else:
    venv_python = venv_path / "bin" / "python"

# Upgrade pip
print("\n[2/4] Upgrading pip...")
subprocess.run([str(venv_python), "-m", "pip", "install", "--upgrade", "pip"], check=True)
print("✓ pip upgraded")

# Install package
print("\n[3/4] Installing ResonanceForge...")
subprocess.run([str(venv_python), "-m", "pip", "install", "-e", "."], check=True)
print("✓ ResonanceForge installed")

# Create launcher
print("\n[4/4] Creating launcher...")
if platform.system() == "Windows":
    launcher = Path("run_resonanceforge.bat")
    launcher.write_text(
        "@echo off\n"
        "call venv\\Scripts\\activate.bat\n"
        "python -m resonanceforge\n"
        "pause\n"
    )
    print("✓ Created run_resonanceforge.bat")
else:
    launcher = Path("run_resonanceforge.sh")
    launcher.write_text(
        "#!/bin/bash\n"
        "source venv/bin/activate\n"
        "python -m resonanceforge\n"
    )
    launcher.chmod(0o755)
    print("✓ Created run_resonanceforge.sh")

print("\n" + "=" * 70)
print(" Installation Complete!")
print("=" * 70)
print()
print("To run ResonanceForge:")
if platform.system() == "Windows":
    print("  run_resonanceforge.bat")
else:
    print("  ./run_resonanceforge.sh")
print()
print("Documentation: docs/")
print("Examples: examples/")
print()
